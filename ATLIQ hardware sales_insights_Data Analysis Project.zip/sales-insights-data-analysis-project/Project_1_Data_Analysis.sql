-- SELECT * FROM sales.transactions Where market_code="Mark001" limit 10;
-- SELECT * FROM sales.transactions Where currency="USD";

# select sales.transactions.*, sales.date.*
# From sales.transactions inner join sales.date on sales.transactions.order_date = sales.date.date
# where sales.date.year="2020"
# Order by sales_qty;

# select SUM(sales.transactions.sales_amount)
# From sales.transactions inner join sales.date on sales.transactions.order_date = sales.date.date
# where sales.date.year="2020" and sales.transactions.market_code="Mark003" ;

-- select distinct market_code from sales.transactions;
-- SELECT count(*) FROM transactions where transactions.currency='INR\r';

# Select sum(transactions.sales_amount) as tsa
# FROM transactions INNER JOIN date ON transactions.order_date = date.date
# WHERE date.year = 2020 and date.month_name = "January"
# and (transactions.currency="INR\r" or transactions.currency="USD\r");

